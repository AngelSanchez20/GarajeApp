<div align="center">

# 📱 Android 2º DAM — AppPrueba (Sesión 7: RecyclerView e Historial)

*Repositorio oficial para las prácticas, proyectos y ejercicios desarrollados en la asignatura de **Desarrollo de Aplicaciones para Dispositivos Móviles** (2º de DAM).*

![Badge Android Studio](https://img.shields.io/badge/Android%20Studio-3DDC84?style=for-the-badge&logo=android-studio&logoColor=white)
![Badge Kotlin](https://img.shields.io/badge/Kotlin-0095D5?style=for-the-badge&logo=kotlin&logoColor=white)
![Badge RecyclerView](https://img.shields.io/badge/RecyclerView-Android-blue?style=for-the-badge)
![Badge Estado](https://img.shields.io/badge/Estado-En%20Desarrollo-orange?style=for-the-badge)

</div>

---

## 📌 Tabla de Contenidos
- [📖 Acerca del Proyecto](#-acerca-del-proyecto)
- [📱 Características](#-características)
- [🛠️ Tecnologías y Herramientas](#-tecnologías-y-herramientas)
- [📂 Estructura del Proyecto](#-estructura-del-proyecto)
- [🚀 Cómo ejecutar el proyecto](#-cómo-ejecutar-el-proyecto)

---

## 📖 Acerca del Proyecto

Esta aplicación corresponde a la **Sesión 7 (RecyclerView)** de la asignatura **Programación Multimedia y Dispositivos Móviles (2º DAM)**.

Añade un sistema de **historial dinámico** que registra las personas procesadas a través del formulario principal en un objeto singleton (`Historial`) y las muestra en una lista optimizada utilizando `RecyclerView`.

---

## 📱 Características

- **Formulario interactivo y persistencia temporal**: Registra el nombre y la edad de los usuarios y guarda automáticamente las entradas válidas en un objeto de datos compartido (`Historial.personas`).
- **Navegación completa entre 3 pantallas**:
  - `MainActivity`: Formulario de registro y acceso directo al historial.
  - `SecondActivity`: Confirmación y saludo personalizado.
  - `HistorialActivity`: Pantalla con `RecyclerView` para listar a todas las personas registradas.
- **Visualización con `RecyclerView`**:
  - Implementación de `HistorialAdapter` y `PersonaViewHolder`.
  - Diseño de fila personalizado en `fila_persona.xml`.
- **Validación robusta con `Toast`**: Comprueba que el nombre no esté vacío y que la edad introducida sea un número válido.

---

## 🛠️ Tecnologías y Herramientas

| Categoría | Herramienta / Tecnología |
| :--- | :--- |
| **Lenguaje** | `Kotlin` |
| **Entorno de Desarrollo** | `Android Studio` |
| **Listas Dinámicas** | `RecyclerView` (`androidx.recyclerview`) |
| **Patrones de Diseño** | Singleton (`object Historial`), Data Class (`Persona`), Adapter |
| **Almacenamiento** | `SharedPreferences` + Memoria dinámica (`mutableListOf`) |
| **Diseño UI** | `XML Layouts` (`LinearLayout`) |

---

## 📂 Estructura del Proyecto

```
App1/
├── app/src/main/
│   ├── java/com/example/appprueba/
│   │   ├── MainActivity.kt       # Formulario, validación y guardado
│   │   ├── SecondActivity.kt     # Pantalla de saludo individual
│   │   ├── HistorialActivity.kt  # Pantalla del historial con RecyclerView
│   │   ├── HistorialAdapter.kt   # Adaptador para RecyclerView
│   │   ├── Historial.kt          # Objeto singleton de almacenamiento
│   │   └── Persona.kt            # Data class de datos (nombre y edad)
│   ├── res/layout/
│   │   ├── activity_main.xml     # Layout principal
│   │   ├── activity_second.xml   # Layout secundario
│   │   ├── activity_historial.xml# Layout del historial (RecyclerView)
│   │   └── fila_persona.xml      # Layout individual de cada fila
│   └── AndroidManifest.xml       # Registro de actividades
└── README.md
```

---

## 🚀 Cómo ejecutar el proyecto

1. Clona el repositorio:
   ```bash
   git clone https://github.com/AngelSanchez20/Android2DAM.git
   ```
2. Abre el proyecto en **Android Studio**.
3. Deja que Gradle sincronice las dependencias.
4. Ejecuta la aplicación en un emulador Android o dispositivo físico conectado mediante depuración USB.
