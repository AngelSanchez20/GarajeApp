package com.example.appprueba

data class Persona(val nombre: String, val edad: Int)
