package com.example.appprueba

object Historial {
    val personas = mutableListOf<Persona>()
}
