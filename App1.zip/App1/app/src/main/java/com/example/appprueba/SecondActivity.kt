package com.example.appprueba

import android.media.MediaPlayer
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity

class SecondActivity : ComponentActivity() {

    // Lo declaramos aquí arriba para poder liberarlo luego en onDestroy
    private var mediaPlayer: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        val textoSaludo = findViewById<TextView>(R.id.textoSaludoPersonalizado)
        val botonVolver = findViewById<Button>(R.id.botonVolver)

        val nombre = intent.getStringExtra("NOMBRE_EXTRA") ?: ""
        val edad = intent.getStringExtra("EDAD_EXTRA") ?: ""

        textoSaludo.text = "Hola, $nombre, tienes $edad años"

        // Convertimos el texto de la edad a número (si está vacío o falla, queda null)
        val edadNumero = edad.toIntOrNull()

        if (edadNumero != null) {
            // Elegimos el sonido según la edad
            val sonido = when {
                edadNumero < 12 -> R.raw.uwu
                edadNumero <= 18 -> R.raw.tigrejoven
                else -> R.raw.tigremayor
            }

            mediaPlayer = MediaPlayer.create(this, sonido)
            mediaPlayer?.start()
        }

        botonVolver.setOnClickListener {
            finish()
        }
    }

    // Cuando se cierra la activity, liberamos el sonido para no gastar memoria
    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer?.release()
        mediaPlayer = null
    }
}